CREATE TRIGGER delete_drinker
BEFORE DELETE ON drinkers
FOR EACH ROW
  UPDATE frequents SET frequents.drinker_id = -1
  WHERE OLD.id = frequents.drinker_id;
