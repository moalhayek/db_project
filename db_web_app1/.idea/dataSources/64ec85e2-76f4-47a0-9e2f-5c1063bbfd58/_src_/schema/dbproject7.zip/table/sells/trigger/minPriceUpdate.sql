CREATE TRIGGER minPriceUpdate
BEFORE UPDATE ON sells
FOR EACH ROW
  BEGIN 
      IF NEW.price <= (SELECT manf_price
                       FROM beers
                       WHERE beers.id = NEW.beer_id) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot sell beer for less than you buy it for';
      END IF;
    END;
