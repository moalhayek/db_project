CREATE TRIGGER AlcoholicTrig
BEFORE INSERT ON drinkers
FOR EACH ROW
  BEGIN
      IF NEW.spending_per_night >= (NEW.salary/(365*2)) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot add drinker, he is an alcoholic';
      ELSEIF NEW.age < 21 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot add drinker, he is under the legal drinking age';
      END IF;
    END;
